import java.util.Arrays;
import java.util.Comparator;

class Book {
    String bookId;
    String title;
    String author;

    // Constructor
    public Book(String bookId, String title, String author) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
    }

    @Override
    public String toString() {
        return "Book ID: " + bookId + ", Title: " + title + ", Author: " + author;
    }
}

public class LibraryManagementSystem {

    // Linear Search
    public static Book linearSearch(Book[] books, String title) {
        for (Book book : books) {
            if (book.title.equals(title)) {
                return book;
            }
        }
        return null;
    }

    // Binary Search
    public static Book binarySearch(Book[] books, String title) {
        int left = 0;
        int right = books.length - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;
            int comparison = books[mid].title.compareTo(title);

            if (comparison == 0) {
                return books[mid];
            } else if (comparison < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }

    public static void main(String[] args) {
        // Create an array of books
        Book[] books = {
            new Book("B003", "Java Programming", "John Doe"),
            new Book("B001", "Data Structures", "Jane Smith"),
            new Book("B002", "Algorithms", "Emily Johnson")
        };

        // Sort the books array by title for binary search
        Arrays.sort(books, Comparator.comparing(book -> book.title));

        // Linear Search
        Book foundBook1 = linearSearch(books, "Algorithms");
        System.out.println("Linear Search Result:");
        System.out.println(foundBook1 != null ? foundBook1 : "Book not found");

        // Binary Search
        Book foundBook2 = binarySearch(books, "Algorithms");
        System.out.println("\nBinary Search Result:");
        System.out.println(foundBook2 != null ? foundBook2 : "Book not found");
    }
}
