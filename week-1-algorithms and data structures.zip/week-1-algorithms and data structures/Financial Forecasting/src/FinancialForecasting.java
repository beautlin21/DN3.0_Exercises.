public class FinancialForecasting {

    // Recursive method to calculate future value
    public static double calculateFutureValue(double currentValue, double growthRate, int periods) {
        // Base case: no more periods to forecast
        if (periods == 0) {
            return currentValue;
        }
        // Recursive case: calculate future value for one period less
        return calculateFutureValue(currentValue * (1 + growthRate), growthRate, periods - 1);
    }

    public static void main(String[] args) {
        double currentValue = 1000; // Initial value
        double growthRate = 0.05;   // Growth rate (5%)
        int periods = 10;           // Number of periods

        // Calculate future value
        double futureValue = calculateFutureValue(currentValue, growthRate, periods);
        System.out.printf("Future Value after %d periods: %.2f%n", periods, futureValue);
    }
}
