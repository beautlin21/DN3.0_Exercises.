import java.util.Arrays;
import java.util.Comparator;

class Product {
    String productId;
    String productName;
    String category;

    // Constructor
    public Product(String productId, String productName, String category) {
        this.productId = productId;
        this.productName = productName;
        this.category = category;
    }

    @Override
    public String toString() {
        return "Product ID: " + productId + ", Name: " + productName + ", Category: " + category;
    }
}

 public class ECommerceSearch {

    // Linear Search
    public static Product linearSearch(Product[] products, String targetName) {
        for (Product product : products) {
            if (product.productName.equals(targetName)) {
                return product;
            }
        }
        return null;
    }

    // Binary Search
    public static Product binarySearch(Product[] products, String targetName) {
        // Sort the array based on product names
        Arrays.sort(products, Comparator.comparing(p -> p.productName));

        int left = 0;
        int right = products.length - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;
            int comparison = products[mid].productName.compareTo(targetName);

            if (comparison == 0) {
                return products[mid];
            } else if (comparison < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }

    public static void main(String[] args) {
        Product[] products = {
            new Product("001", "Laptop", "Electronics"),
            new Product("002", "Smartphone", "Electronics"),
            new Product("003", "Book", "Books"),
            new Product("004", "Shoes", "Fashion")
        };

        // Linear Search
        Product foundProduct1 = linearSearch(products, "Book");
        System.out.println(foundProduct1 != null ? "Product found (Linear Search): " + foundProduct1 : "Product not found (Linear Search)");

        // Binary Search
        Product foundProduct2 = binarySearch(products, "Book");
        System.out.println(foundProduct2 != null ? "Product found (Binary Search): " + foundProduct2 : "Product not found (Binary Search)");
    }
}
