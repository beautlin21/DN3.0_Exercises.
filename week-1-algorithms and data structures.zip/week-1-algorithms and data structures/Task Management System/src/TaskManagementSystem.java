class Task {
    String taskId;
    String taskName;
    String status;

    // Constructor
    public Task(String taskId, String taskName, String status) {
        this.taskId = taskId;
        this.taskName = taskName;
        this.status = status;
    }

    @Override
    public String toString() {
        return "Task ID: " + taskId + ", Name: " + taskName + ", Status: " + status;
    }
}

class Node {
    Task task;
    Node next;

    // Constructor
    public Node(Task task) {
        this.task = task;
        this.next = null;
    }
}

public class TaskManagementSystem {
    private Node head;

    // Constructor
    public TaskManagementSystem() {
        head = null;
    }

    // Add Task
    public void addTask(Task task) {
        Node newNode = new Node(task);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    // Search Task by ID
    public Task searchTask(String taskId) {
        Node current = head;
        while (current != null) {
            if (current.task.taskId.equals(taskId)) {
                return current.task;
            }
            current = current.next;
        }
        return null;
    }

    // Traverse Tasks
    public void traverseTasks() {
        Node current = head;
        while (current != null) {
            System.out.println(current.task);
            current = current.next;
        }
    }

    // Delete Task by ID
    public boolean deleteTask(String taskId) {
        if (head == null) return false;

        if (head.task.taskId.equals(taskId)) {
            head = head.next;
            return true;
        }

        Node current = head;
        while (current.next != null) {
            if (current.next.task.taskId.equals(taskId)) {
                current.next = current.next.next;
                return true;
            }
            current = current.next;
        }
        return false;
    }

    public static void main(String[] args) {
        TaskManagementSystem tms = new TaskManagementSystem();

        // Adding Tasks
        tms.addTask(new Task("T001", "Design Database", "In Progress"));
        tms.addTask(new Task("T002", "Develop API", "Not Started"));
        tms.addTask(new Task("T003", "Test Application", "In Progress"));

        // Traversing Tasks
        System.out.println("Task Records:");
        tms.traverseTasks();

        // Searching for a Task
        Task foundTask = tms.searchTask("T002");
        System.out.println("\nSearch Result:");
        System.out.println(foundTask != null ? foundTask : "Task not found");

        // Deleting a Task
        boolean isDeleted = tms.deleteTask("T001");
        System.out.println("\nDeletion Result:");
        System.out.println(isDeleted ? "Task deleted" : "Task not found");

        // Traversing Tasks after Deletion
        System.out.println("\nTask Records after Deletion:");
        tms.traverseTasks();
    }
}
