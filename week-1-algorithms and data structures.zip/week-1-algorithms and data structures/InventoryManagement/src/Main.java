
import java.util.HashMap;

class InventoryManagementSystem {
    private HashMap<String, Product> inventory;

    public InventoryManagementSystem() {
        this.inventory = new HashMap<>();
    }

    // Method to add a product
    public void addProduct(Product product) {
        inventory.put(product.productId, product);
    }

    // Method to update a product
    public void updateProduct(Product product) {
        inventory.put(product.productId, product);
    }

    // Method to delete a product
    public void deleteProduct(String productId) {
        inventory.remove(productId);
    }

    // Method to retrieve a product
    public Product getProduct(String productId) {
        return inventory.get(productId);
    }
}
class Product {
    String productId;
    String productName;
    int quantity;
    double price;

  
    public Product(String productId, String productName, int quantity, double price) {
        this.productId = productId;
        this.productName = productName;
        this.quantity = quantity;
        this.price = price;
    }

   
}



public class Main {

	    public static void main(String[] args) {
	        InventoryManagementSystem ims = new InventoryManagementSystem();

	        Product product1 = new Product("001", "Laptop", 10, 999.99);
	        Product product2 = new Product("002", "Smartphone", 20, 499.99);

	        ims.addProduct(product1);
	        ims.addProduct(product2);

	        product1.quantity = 15;
	        ims.updateProduct(product1);

	        System.out.println("Product 001 details: " + ims.getProduct("001").productName);

	        ims.deleteProduct("002");
	    }
	}


