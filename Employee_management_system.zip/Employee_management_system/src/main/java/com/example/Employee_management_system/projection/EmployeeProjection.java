// src/main/java/com/example/Employee_management_system/projection/EmployeeProjection.java
package com.example.Employee_management_system.projection;

public interface EmployeeProjection {
    Long getId();
    String getName();
    String getEmail();
}
