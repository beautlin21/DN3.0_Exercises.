-- src/main/resources/data.sql
INSERT INTO departments (name) VALUES ('HR');
INSERT INTO departments (name) VALUES ('IT');

INSERT INTO employees (name, email, department_id) VALUES ('John Doe', 'john.doe@example.com', 1);
INSERT INTO employees (name, email, department_id) VALUES ('Jane Smith', 'jane.smith@example.com', 2);
