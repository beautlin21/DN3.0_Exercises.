package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.repository.BookRepository;

@Service
public class BookService {

    private final BookRepository bookRepository;

    
    @Autowired
    public BookService(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    
    public void findBook(int id) {
        System.out.println("BookService: Searching for book with ID: " + id);
        bookRepository.findBookById(id);
    }
}
