package com.examplee;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.example.service.BookService;

public class LibraryManagementApplication {
    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

        
        BookService bookService = context.getBean("bookService", BookService.class);

        
        if (bookService != null) {
            System.out.println("BookService bean has been successfully injected.");
            bookService.performService(); // This should trigger logging before and after the method
        } else {
            System.out.println("Failed to inject BookService bean.");
        }
    }
}
